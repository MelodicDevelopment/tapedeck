# Handoff: Tapedeck — Lightweight YouTube Music Player

## Overview
Tapedeck is a minimal desktop app that turns a pasted YouTube channel or playlist URL into a focused, distraction-free music player. It plays the source's videos in sequence with basic transport controls. Intentionally excluded: accounts, social features, comments, recommendations, downloads, equalizers, playlist management.

## About the Design Files
`Tapedeck.dc.html` is a **design reference created in HTML** — an interactive prototype showing intended look and behavior, not production code. The task is to **recreate this design in the target codebase's environment** (Electron + React, Tauri, web app, etc.) using its established patterns. If no environment exists yet, a sensible default is Electron or Tauri with React, since this is a desktop-first app that needs the YouTube IFrame Player API.

The prototype *simulates* playback (fake track data, striped placeholder thumbnails, a ticking progress timer). Production must integrate:
- **YouTube IFrame Player API** for actual playback (the player must remain visible per YouTube TOS — the design reserves a 16:9 area for it).
- **YouTube Data API v3** (`playlistItems.list`, `channels.list`) to resolve a pasted URL into a title, thumbnail, and ordered video list.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and states are final. Recreate pixel-perfectly; replace placeholder thumbnails with real YouTube thumbnails (`https://i.ytimg.com/vi/<id>/mqdefault.jpg`) and the placeholder video area with the real embedded player.

## Screens / Views

### 1. Welcome (empty state)
Full-window, single column, everything centered.
- **Top-left brand**: 26px rounded square (radius 8, accent bg) containing a small dark play glyph + "Tapedeck" 15px/600.
- **Center block** (max-width 520px, centered text):
  - H1 "Play the channels you love" — 30px/700, letter-spacing -0.02em, margin-bottom 10px.
  - Supporting copy — 15px/400, line-height 1.55, color `#9a948a`, max-width 400px, margin-bottom 32px: "Paste a YouTube channel or playlist and Tapedeck turns it into a clean, distraction-free music player."
  - **Input row** (flex, gap 10): URL input flex-1, height 46, padding 0 16, radius 10, bg `#211e1a`, border 1px `#3a3630`, text 14px `#f0ede7`, placeholder "https://www.youtube.com/…". Focus: border becomes accent + 3px soft accent ring `rgba(139,127,240,.22)`.
  - **Load button**: height 46, padding 0 22, radius 10, bg accent `#8b7ff0`, text `#14120f` 14px/600. Hover: brightness 1.08. Focus: 2px `#e8e4dc` outline offset 2.
  - Helper line below (13px, `#6f6a61`): "Try youtube.com/@aurorakeys" — example is a clickable text button (monospace 12px, underlined) that fills the input.
- **Footer** (centered, 12px `#6f6a61`): "Plays videos directly from YouTube · nothing is downloaded".

### 2. Loading
Same layout as Welcome; center block replaced with:
- 44px spinner: 3px ring `#33302b` with accent top segment, 0.8s linear rotation.
- "Fetching from YouTube…" 20px/600, then 14px `#9a948a` explainer.

### 3. Invalid URL (error state)
Welcome layout; input border turns `#a05548`; below the input a `role="alert"` line, 13px `#e08a7c`, with a 14px circle-exclamation line icon. Two messages:
- Empty input: "Paste a YouTube channel or playlist URL first."
- Non-YouTube URL: "That doesn't look like a YouTube link. Try a channel or playlist URL."
Error clears on input change. Validation in the prototype: URL must match `/youtube\.com|youtu\.be/i`.

### 4. Player (loaded state)
Three regions: left sidebar (312px fixed), main area (flex-1), bottom bar (84px fixed, full width).

#### Sidebar (`#1b1916`, right border 1px `#26231f`)
- **Source card** (padding 16/16/14, bottom border `#26231f`): 44×44 thumbnail radius 10, name 14px/600 truncated, meta "YouTube channel · 12 videos" 12px `#9a948a`. Right: 30×30 icon button (refresh/swap line icon, 1px border `#33302b`, radius 8, color `#9a948a`) = "load a different URL" → returns to Welcome (URL preserved). Hover: text `#f0ede7`, border `#4a453e`.
- **Track list** (scrollable, padding 8, `role="list"`): each row a full-width button — flex, gap 11, padding 8, radius 9, margin-bottom 2.
  - Thumbnail 50×30 radius 6 (compact mode: 42×26).
  - Title 13.5px/500 `#e6e2da` truncated; subtitle 12px `#8f897f` (e.g. "Solo piano").
  - Duration right-aligned, 12px `#6f6a61`, tabular-nums.
  - **Current row**: bg `#26221b`, title 600 in accent color, thumbnail overlaid with dark scrim + 3-bar animated "equalizer" in accent (bars 3px wide, heights cycle each second).
  - **Unavailable row**: title `#6f6a61`, subtitle "Unavailable on YouTube".
  - Hover: bg `#242119`. Focus: 2px accent outline inset.

#### Main area
- **Header row** (padding 18 32 0, space-between): small brand mark left; right badge "Streaming from YouTube" — 12px `#6f6a61` with a 15×11 red rounded-rect play icon (YouTube attribution).
- **Video player** (centered column, max-width 880, padding 20 32 24): 16:9 box, radius 14, border 1px `#2b2823`, shadow `0 8px 32px rgba(0,0,0,.35)`, bg `#0f0e0c`. This is where the YouTube iframe mounts — nothing may overlap it. Bottom-left chip in prototype ("YouTube player", 11.5px on `rgba(15,14,12,.72)`) is placeholder-only; omit over a real iframe.
- **Track info row** below (baseline-aligned, space-between): title 19px/600 truncated; "Aurora Keys · Solo piano" 13.5px `#9a948a`; right "Track 3 of 12" 12.5px `#6f6a61` tabular-nums.

#### Unavailable video state (in player area)
Overlay `rgba(15,14,12,.9)` covering the video box: crossed-circle line icon 34px `#6f6a61`, "This video is unavailable" 16px/600, explainer 13px `#9a948a` ("It may be private or removed on YouTube. You can skip it and keep listening."), and a "Skip to next" accent button (padding 9 20, radius 9). Playback pauses; progress shows 0:00.

#### Bottom bar (84px, `#1b1916`, top border `#26231f`, padding 0 20, gap 24)
- **Left (260px)**: 52×34 thumbnail radius 7 + title 13.5px/600 + source name 12px `#8f897f`, both truncated.
- **Center (flex-1, column, gap 8)**:
  - Transport row, gap 18: prev / play-pause / next.
    - Prev & next: 34px circular ghost buttons, `#c9c4bb` line icons (bar + triangle). Hover: `#f0ede7` on `#242119`.
    - Play/pause: 42px circle, bg `#f0ede7`, dark glyph. Hover scale 1.05. Icon toggles play ▶ / pause ⏸.
  - Progress row (max-width 560): elapsed left 11.5px `#8f897f` tabular-nums; 4px track `#33302b` radius 2 with accent fill; remaining right prefixed "-". Click-to-seek. Keyboard-focusable (`role="slider"`).
- **Right (180px)**: speaker line icon `#8f897f` + 96px range slider (4px track `#3a3630`, 12px round thumb `#e8e4dc`).

## Interactions & Behavior
- **Load flow**: Enter key or Load button → validate → loading (~1.4s in prototype; real: API fetch) → player with track 1 auto-playing.
- **Track select**: click a row → that track plays from 0:00. Selecting an unavailable track shows the unavailable overlay, paused.
- **Prev/Next**: wrap around the list. Auto-advance when a track ends.
- **Seek**: click position on progress bar sets elapsed time proportionally.
- **Change source**: sidebar refresh button → Welcome state, previous URL kept in the input.
- **Transitions**: none/instant; keep it snappy. Only animations: spinner (0.8s linear), equalizer bars (1s step), play button hover scale.
- **Responsive**: below ~900px collapse to single column — track list under the player, bottom bar persists. (Not built in the prototype; design intent.)

## State Management
- `view`: 'empty' | 'loading' | 'loaded' (+ error string shown within 'empty')
- `url`, `error`
- `source`: { name, thumbnail, videoCount }
- `tracks[]`: { videoId, title, subtitle/channel, duration, unavailable }
- `currentIndex`, `playing`, `elapsed`, `volume`
- Real app: player state (elapsed, duration, ended, error 100/101/150 → unavailable) comes from YouTube IFrame API events, not a timer.

## Design Tokens
Colors (warm charcoal, dark theme):
- Background: `#171512` · Panel (sidebar/bottom bar): `#1b1916` · Input/wells: `#211e1a` · Video well: `#0f0e0c`
- Raised/selected row: `#26221b` · Hover row: `#242119`
- Borders: `#26231f` (panels), `#2b2823` (video), `#33302b` / `#3a3630` (controls), `#4a453e` (hover)
- Text: primary `#f0ede7`, list titles `#e6e2da`, controls `#c9c4bb`, secondary `#9a948a`, tertiary `#8f897f`, faint `#6f6a61`
- Accent: `#8b7ff0` (soft violet). Alternates approved in tweaks: `#7fb0e8`, `#7cc4a4`, `#e0a973`
- Error: text `#e08a7c`, border `#a05548`
- Play button fill: `#f0ede7` with `#14120f` glyph; text on accent: `#14120f`

Typography — **Albert Sans** (Google Fonts), weights 400/500/600/700; monospace only for the example URL:
- H1 30/700 · Loading heading 20/600 · Track title 19/600 · Card titles 14/600 · Body 15/400 lh 1.55 · List 13.5 · Meta 12–13 · Timestamps 11.5 tabular-nums

Spacing/radius/shadows:
- Radii: 14 (video), 10 (input, buttons, source thumb), 9 (rows), 8 (icon btn), 7 (bar thumb), 6 (list thumbs), full (transport)
- Key paddings: sidebar 16, main gutter 32, list rows 8, bar 0 20
- Shadow: only on video box `0 8px 32px rgba(0,0,0,.35)`

## Accessibility
- All controls are real buttons/inputs with aria-labels (prev/next/play-pause/volume/seek/change-source).
- Visible focus: 2px accent outline (offset 2; inset on list rows); `#e8e4dc` outline on accent-filled buttons.
- Error message uses `role="alert"`.

## Assets
No image assets. Striped thumbnails are placeholders — replace with real YouTube thumbnails. Icons are simple inline line SVGs (play, pause, prev, next, volume, refresh, alert, crossed circle, YouTube badge); recreate with any line icon set (e.g. Lucide) at matching sizes/stroke ~1.4–1.5.

## Files
- `Tapedeck.dc.html` — the full interactive prototype (all states: welcome, loading, invalid URL, loaded, unavailable video). Template markup + a `Component` logic class with mock data.
